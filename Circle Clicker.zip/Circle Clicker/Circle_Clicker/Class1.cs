﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Circle_Clicker
{
    class Circle
    {
        
        public Vector2 vecCircle;
        public Texture2D texCircle;
        public int xMoveFactor;
        public int yMoveFactor;
        public Rectangle hitboxCircle;
        public GraphicsDeviceManager graphics;
        public bool isOnedead = false;
        Color circleColor;
        Random random;
        public Circle(Vector2 _vecCircle, Texture2D _texCircle, int _xMoveFactor, int _yMoveFactor, GraphicsDeviceManager _graphics, Random _random)
        {
            vecCircle = _vecCircle;
            texCircle = _texCircle;
            xMoveFactor = _xMoveFactor;
            yMoveFactor = _yMoveFactor;
            graphics = _graphics;
            hitboxCircle.X = (int)vecCircle.X;
            hitboxCircle.Y = (int)vecCircle.Y;
            hitboxCircle.Width = texCircle.Width;
            hitboxCircle.Height = texCircle.Height;
            random = _random;

            circleColor = new Color(random.Next(45, 255), random.Next(45, 255), random.Next(45, 255));

        }
        public void Update()
        {
            if (vecCircle.X <= 0)
            {
                xMoveFactor = Math.Abs(xMoveFactor);
            }
            if (vecCircle.X + texCircle.Width >= graphics.PreferredBackBufferWidth)
            {
                xMoveFactor = -Math.Abs(xMoveFactor);
            }
            if (vecCircle.Y <= 0)
            {
                yMoveFactor = Math.Abs(yMoveFactor);
            }
            if (vecCircle.Y + texCircle.Height >= graphics.PreferredBackBufferHeight)
            {
                xMoveFactor = 0;
                yMoveFactor = 0;
                isOnedead = true;
            }
            vecCircle.X += (float)xMoveFactor;
            vecCircle.Y += (float)yMoveFactor;
            hitboxCircle.X = (int)vecCircle.X;
            hitboxCircle.Y = (int)vecCircle.Y;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
             spriteBatch.Draw(texCircle, vecCircle, circleColor);
        }
        public void DrawDark(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texCircle, vecCircle, new Color(circleColor.R/3, circleColor.G/3, circleColor.B/3));
        }


    }
}
