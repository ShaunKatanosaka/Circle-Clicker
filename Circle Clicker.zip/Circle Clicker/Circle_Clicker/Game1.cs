using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
//using Microsoft.Xna.Framework.Storage;
namespace Circle_Clicker
{

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        KeyboardState keyboardState2;
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Random random = new Random();
        Vector2 vecMouseCursor = new Vector2(0, 0);
        Texture2D texMouseCursor;
        List<Circle> circles = new List<Circle>();
        List<bool> antiDoubleClickBool = new List<bool>();
        List<bool> antiCheatBool = new List<bool>();
        TimeSpan time = TimeSpan.Zero;
        TimeSpan totalTime = TimeSpan.Zero;
        bool stopGame = false;
        SpriteFont spriteFont;
        decimal highScore = 0;
        string gameTimer;
        bool highScoreBool = false;
        bool keyboardMode = true;
        int deadCircleIndex = 0;
        bool hitOne = false;
        public Game1()
        {

            graphics = new GraphicsDeviceManager(this)
            {
                PreferredBackBufferHeight = 950,
                PreferredBackBufferWidth = 1200
            };
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = Content.Load<SpriteFont>("SpriteFont1");
            texMouseCursor = this.Content.Load<Texture2D>("Image2");
            circles.Add(new Circle(new Vector2(random.Next(0, 1000), 800), Content.Load<Texture2D>("Image1"), 10, -10, graphics, random));
        }

        protected override void UnloadContent()
        {

        }


        public struct HighScores
        {
            public int[] highScores;
            
            public HighScores(int count)
            {
                highScores = new int[count];
            }
        }

        //public static void SaveHighScores(HighScores scores, string fileName)
        //{
        //    string fullpath = Path.Combine()
        //}
        
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
            {
                this.Exit();
            }

            if (!stopGame)
            {
                totalTime += gameTime.ElapsedGameTime;
                time += gameTime.ElapsedGameTime;
                gameTimer = Math.Round((decimal)totalTime.TotalSeconds, 3).ToString();
            }
            MouseState mouseState = Mouse.GetState();
            KeyboardState keyboardState = Keyboard.GetState();

            if (keyboardState.IsKeyDown(Keys.K) && keyboardState2.IsKeyUp(Keys.K))
            {
                keyboardMode = !keyboardMode;
            }

            if (keyboardState.IsKeyDown(Keys.R) && keyboardState2.IsKeyUp(Keys.R))
            {
                totalTime = TimeSpan.Zero;
                time = TimeSpan.Zero;
                circles.Clear();
                circles.Add(new Circle(new Vector2(random.Next(0, 1000), 800), Content.Load<Texture2D>("Image1"), 10, -10, graphics, random));
                stopGame = false;
                highScoreBool = false;

            }

            vecMouseCursor.X = mouseState.X;
            vecMouseCursor.Y = mouseState.Y;
            if (time.Seconds >= 2 && !stopGame)
            {
                circles.Add(new Circle(new Vector2(random.Next(0, 1000), 800), Content.Load<Texture2D>("Image1"), 10, -10, graphics, random));
                time = TimeSpan.Zero;
            }
            for (int i = 0; i < circles.Count; i++)
            {
                if (circles[i].isOnedead)
                {
                    for (int s = 0; s < circles.Count; s++)
                    {
                        circles[s].xMoveFactor = 0;
                        circles[s].yMoveFactor = 0;
                        stopGame = true;
                        if (highScore < (decimal)totalTime.TotalSeconds)
                        {
                            highScore = (decimal)totalTime.TotalSeconds;
                            highScoreBool = true;
                        }
                    }
                    deadCircleIndex = i;
                    break;
                }
            }

            if (antiDoubleClickBool.Count < circles.Count)
            {
                antiDoubleClickBool.Add(new bool());
            }
            if (antiCheatBool.Count < circles.Count)
            {
                antiCheatBool.Add(new bool());
            }
            for (int i = 0; i > 0; i++)
            {
                antiCheatBool[i] = true;
                antiDoubleClickBool[i] = true;
            }
            for (int i = 0; i < circles.Count; i++)
            {
                circles[i].Update();
                
                if (!keyboardMode)
                {
                    if (!circles[i].hitboxCircle.Contains(mouseState.X, mouseState.Y) && mouseState.LeftButton == ButtonState.Pressed)
                    {
                        antiCheatBool[i] = false;
                    }
                    else if (circles[i].hitboxCircle.Contains(mouseState.X, mouseState.Y) && mouseState.LeftButton == ButtonState.Pressed && antiDoubleClickBool[i] && antiCheatBool[i])
                    {
                        circles[i].yMoveFactor *= -1;
                        antiDoubleClickBool[i] = false;
                        hitOne = true;
                    }
                    else if (!(mouseState.LeftButton == ButtonState.Pressed))
                    {
                        antiCheatBool[i] = true;
                    }
                    if (!(mouseState.LeftButton == ButtonState.Pressed))
                    {
                        antiDoubleClickBool[i] = true;
                    }
                }
                else
                {
                    if (!circles[i].hitboxCircle.Contains(mouseState.X, mouseState.Y) && keyboardState.IsKeyDown(Keys.Z))
                    {
                        antiCheatBool[i] = false;
                    }
                    else if (circles[i].hitboxCircle.Contains(mouseState.X, mouseState.Y) && keyboardState.IsKeyDown(Keys.Z) && antiDoubleClickBool[i] && antiCheatBool[i])
                    {
                        circles[i].yMoveFactor *= -1;
                        antiDoubleClickBool[i] = false;
                        hitOne = true;
                    }
                    else if (!(keyboardState.IsKeyDown(Keys.Z)))
                    {
                        antiCheatBool[i] = true;
                    }
                    if (!keyboardState.IsKeyDown(Keys.Z))
                    {
                        antiDoubleClickBool[i] = true;
                    }

                }
                if (hitOne)
                {
                    hitOne = false;
                    break;
                }
            }
            keyboardState2 = keyboardState;
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            spriteBatch.Begin();
            if (!stopGame)
            {
                for (int i = 0; i < circles.Count; i++)
                {
                    circles[i].Draw(spriteBatch);
                }
            }
            else
            {
                for (int i = 0; i < circles.Count; i++)
                {
                    circles[i].DrawDark(spriteBatch);
                }
                circles[deadCircleIndex].Draw(spriteBatch);
                spriteBatch.Draw(Content.Load<Texture2D>("CircleBorder"), new Vector2(circles[deadCircleIndex].vecCircle.X - 2, circles[deadCircleIndex].vecCircle.Y - 2), Color.White);
            }
            spriteBatch.DrawString(spriteFont, gameTimer, new Vector2((graphics.PreferredBackBufferWidth - spriteFont.MeasureString(gameTimer).X) / 2, 80), Color.White);
            spriteBatch.Draw(texMouseCursor, vecMouseCursor, Color.White);
            if (stopGame)
            {
                if (highScoreBool)
                {
                    spriteBatch.DrawString(spriteFont, Math.Round(highScore, 3).ToString(), new Vector2((graphics.PreferredBackBufferWidth - spriteFont.MeasureString(gameTimer).X) / 2, 110), Color.Red);
                }
                else
                {
                    spriteBatch.DrawString(spriteFont, Math.Round(highScore, 3).ToString(), new Vector2((graphics.PreferredBackBufferWidth - spriteFont.MeasureString(gameTimer).X) / 2, 110), Color.White);
                }
                if(keyboardMode)
                {
                    spriteBatch.Draw(Content.Load<Texture2D>("Z"), new Vector2(graphics.PreferredBackBufferWidth - 200, graphics.PreferredBackBufferHeight - 200), Color.White);
                }
                else
                {
                    spriteBatch.Draw(Content.Load<Texture2D>("LMB"), new Vector2(graphics.PreferredBackBufferWidth - 200, graphics.PreferredBackBufferHeight - 200), Color.White);
                }
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}

